exports.handler = async function(event, context) {
  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ success: false, error: 'Method not allowed' })
    };
  }

  try {
    const { url, claim } = JSON.parse(event.body || '{}');

    if (!url && !claim) {
      return {
        statusCode: 400,
        body: JSON.stringify({ success: false, error: 'Please provide a URL or claim to analyse.' })
      };
    }

    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      return {
        statusCode: 500,
        body: JSON.stringify({ success: false, error: 'API key not configured. Please add ANTHROPIC_API_KEY to your Netlify environment variables.' })
      };
    }

    // Build the prompt — pass URL directly to Claude, no fetching needed
    const prompt = url
      ? `You are a professional fact-checker and misinformation analyst. 

A user has submitted this news article URL for analysis: ${url}

Based on your knowledge of this URL, the news source, and the likely content of this article, please analyse it for accuracy, bias, and potential misinformation.

If you are not familiar with this specific article, analyse the news source's general reliability and provide your best assessment based on the URL structure and source.

Respond ONLY with a valid JSON object in exactly this format, with no extra text before or after:
{
  "verdict": "TRUE",
  "confidence": 85,
  "article_title": "Title of the article if known, or the news source name",
  "summary": "A 2-3 sentence summary of what this article is about",
  "explanation": "A detailed explanation of your verdict, covering the accuracy of claims, source reliability, and any concerns",
  "key_claims": ["First key claim in the article", "Second key claim", "Third key claim"],
  "red_flags": ["Any red flag found, or empty array if none"],
  "sources_mentioned": ["Sources cited in the article or by the publication"]
}

The verdict must be exactly one of: TRUE, FALSE, MISLEADING, UNVERIFIED
- TRUE: Claims are accurate and well-supported by evidence
- FALSE: Claims are inaccurate or contradicted by evidence  
- MISLEADING: Claims are deceptive, lack context, or are presented out of context
- UNVERIFIED: Insufficient evidence to confirm or deny the claims

The confidence must be a number between 0 and 100.`
      : `You are a professional fact-checker and misinformation analyst.

A user has submitted this claim for fact-checking: "${claim}"

Please analyse this claim for accuracy and respond ONLY with a valid JSON object in exactly this format, with no extra text before or after:
{
  "verdict": "TRUE",
  "confidence": 85,
  "article_title": "The claim being checked",
  "summary": "A 2-3 sentence summary of what this claim is about",
  "explanation": "A detailed explanation of your verdict, covering the accuracy of the claim and evidence",
  "key_claims": ["The main claim", "Any related claims"],
  "red_flags": ["Any red flag found, or empty array if none"],
  "sources_mentioned": ["Relevant sources that support or contradict this claim"]
}

The verdict must be exactly one of: TRUE, FALSE, MISLEADING, UNVERIFIED
The confidence must be a number between 0 and 100.`;

    // Call Claude API
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1024,
        messages: [
          {
            role: 'user',
            content: prompt
          }
        ]
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Claude API error:', errorText);
      return {
        statusCode: 500,
        body: JSON.stringify({ success: false, error: 'Failed to connect to AI service. Please try again.' })
      };
    }

    const data = await response.json();
    const rawText = data.content[0].text.trim();

    // Clean the response — remove markdown code blocks if present
    const cleaned = rawText
      .replace(/^```json\s*/i, '')
      .replace(/^```\s*/i, '')
      .replace(/\s*```$/i, '')
      .trim();

    // Parse JSON
    let analysis;
    try {
      analysis = JSON.parse(cleaned);
    } catch (parseError) {
      console.error('JSON parse error:', parseError, 'Raw text:', rawText);
      return {
        statusCode: 500,
        body: JSON.stringify({ success: false, error: 'The AI returned an unexpected response. Please try again.' })
      };
    }

    // Validate verdict
    const validVerdicts = ['TRUE', 'FALSE', 'MISLEADING', 'UNVERIFIED'];
    if (!validVerdicts.includes(analysis.verdict)) {
      analysis.verdict = 'UNVERIFIED';
    }

    // Ensure confidence is a number
    analysis.confidence = parseInt(analysis.confidence) || 50;

    // Ensure arrays exist
    analysis.key_claims = analysis.key_claims || [];
    analysis.red_flags = analysis.red_flags || [];
    analysis.sources_mentioned = analysis.sources_mentioned || [];

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        success: true,
        url: url || '',
        analysis
      })
    };

  } catch (error) {
    console.error('Handler error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, error: 'Something went wrong. Please try again.' })
    };
  }
};
